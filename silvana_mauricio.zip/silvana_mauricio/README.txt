Analisador Léxico

Compilar
	 gcc *.c  -o main -lm -g
Executar 
	./main example.jusm
Saida
	Arquivo com tabela de tokens
	Arquivo com tabela de simbolos
